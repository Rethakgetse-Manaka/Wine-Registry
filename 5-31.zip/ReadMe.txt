Name: Rethakgetse Manaka
Student Number: u22491032
A couple of things to take note of:
The search features on this page have been disabled because of a couple of bugs that I was running into.
The average rating feature is not working.


How to use the website
1. To register a new user. Click on the sign up on the top left of the website navigation bar.
2. To login as a user. Click on the login in the navigation bar. This should redirect you to the login page where you login.
3. After logging in your filters should be applied if they are saved. If they have not been saved nothing will be applied.
4. To save your preferences you need to login and use the save preferences buttion under the filters.
5. To save theme of your choice click on the blank button on the footer underneath the theme section. In order to save a you need to be logged theme you need to be logged in.


Username: Rethakgetse11@gmail.com
Password: Dycroc911$