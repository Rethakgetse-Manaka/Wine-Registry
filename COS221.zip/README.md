# Practical_Assignment_5_COS221
This git repository is for Monica, Retha, Kamo, Kabelo and Victor. This git repository should be used for the COS221 Practical Assignment.
//Wine Types and Categories research: Monica
