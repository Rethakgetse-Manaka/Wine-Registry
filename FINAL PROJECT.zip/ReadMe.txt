In order to use the website there are two methods:

You can access our website hosted on wheatley through the following web address: https://wheatley.cs.up.ac.za/u22491032/Wines.php

through this method you will need to have access to the password and username of the specific student in the group that hosted the website on their wheatley.

OR

You can get it from the archive that was submitted to clickup. 

In that archive there will be a folder that holds the source code of the website and from there you will need have xampp installed on your PC, once you have xampp installed you will need to place this folder with the source code into the directory that holds projects in xampp which should be located in this directory: C:\xampp\htdocs, from here you can copy the folder with the source code into this directory. 

Once this is complete you will need to open xampp and start Apache as well as MySQL.  

The server will be hosted on the localhost so you will have to open your browser and type http://localhost/Name of directory with source code/


After following either one of these steps you will gain access to the website.

Once this is complete you should be able to view the website and utilise it's functionality.

You can signup as a new user, then login and navigate through the various pages in the website.
